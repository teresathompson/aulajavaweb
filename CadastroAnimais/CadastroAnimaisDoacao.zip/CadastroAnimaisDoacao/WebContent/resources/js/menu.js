function carregarPagina(arquivo) {
	$('#main').load(arquivo + '.html');
	
};