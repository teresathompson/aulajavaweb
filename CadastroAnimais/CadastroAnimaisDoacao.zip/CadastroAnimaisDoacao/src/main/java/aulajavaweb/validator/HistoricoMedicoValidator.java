package aulajavaweb.validator;

import aulajavaweb.model.HistoricoMedico;

public class HistoricoMedicoValidator implements Validator<HistoricoMedico>{
	
	@Override
	public boolean validate(HistoricoMedico t){
		return false;
	}

}
