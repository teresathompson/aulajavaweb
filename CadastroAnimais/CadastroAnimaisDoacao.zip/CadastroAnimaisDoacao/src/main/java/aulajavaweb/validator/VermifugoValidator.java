package aulajavaweb.validator;

import aulajavaweb.model.Vermifugo;

public class VermifugoValidator implements Validator<Vermifugo>{
	
	@Override
	public boolean validate(Vermifugo t){
		return false;
	}

}
