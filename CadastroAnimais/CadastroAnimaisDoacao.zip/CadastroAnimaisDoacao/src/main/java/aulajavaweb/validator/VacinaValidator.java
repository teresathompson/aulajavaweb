package aulajavaweb.validator;

import aulajavaweb.model.Vacina;

public class VacinaValidator implements Validator<Vacina>{
	
	public boolean validate(Vacina t){
		return false;
	}

}
