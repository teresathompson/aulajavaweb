package aulajavaweb.validator;

import aulajavaweb.model.Endereco;

public class EnderecoValidator implements Validator<Endereco>{
	
	@Override
	public boolean validate(Endereco t){
		return false;
	}

}
