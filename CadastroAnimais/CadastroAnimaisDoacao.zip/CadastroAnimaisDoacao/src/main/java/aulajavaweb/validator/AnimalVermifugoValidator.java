package aulajavaweb.validator;

import aulajavaweb.model.AnimalVermifugo;

public class AnimalVermifugoValidator implements Validator<AnimalVermifugo>{
	
	@Override
	public boolean validate(AnimalVermifugo t){
		return false;
	}

}
