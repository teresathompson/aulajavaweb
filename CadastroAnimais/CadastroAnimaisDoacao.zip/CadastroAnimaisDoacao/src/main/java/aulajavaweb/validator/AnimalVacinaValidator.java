package aulajavaweb.validator;
import aulajavaweb.model.AnimalVacina;

public class AnimalVacinaValidator implements Validator<AnimalVacina> {

	@Override
	public boolean validate(AnimalVacina t) {
		return false;
	}
	
}