package aulajavaweb.service;

public class VacinaService {

}
