package aulajavaweb.service;

public class HistoricoMedicoService {

}
