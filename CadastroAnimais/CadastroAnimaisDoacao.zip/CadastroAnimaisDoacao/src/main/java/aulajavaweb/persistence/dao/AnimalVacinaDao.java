package aulajavaweb.persistence.dao;

import aulajavaweb.model.AnimalVacina;

public class AnimalVacinaDao extends DaoImpl<AnimalVacina> {

	public AnimalVacinaDao() {
		super(AnimalVacina.class);
	}

}
