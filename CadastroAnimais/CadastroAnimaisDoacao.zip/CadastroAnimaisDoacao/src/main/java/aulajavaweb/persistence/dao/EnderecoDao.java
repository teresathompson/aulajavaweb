package aulajavaweb.persistence.dao;

import aulajavaweb.model.Endereco;

public class EnderecoDao extends DaoImpl<Endereco> {
	
	public EnderecoDao() {
		super(Endereco.class);
	}

}
