package aulajavaweb.persistence.dao;

import aulajavaweb.model.Tutor;

public class TutorDao extends DaoImpl<Tutor> {
	
	public TutorDao() {
		super(Tutor.class);
	}

}
