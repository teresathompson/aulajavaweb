package aulajavaweb.persistence.dao;

import aulajavaweb.model.Vermifugo;

public class VermifugoDao extends DaoImpl<Vermifugo> {

	public VermifugoDao() {
		super(Vermifugo.class);
	}
	
}
