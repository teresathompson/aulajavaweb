package aulajavaweb.persistence.dao;

import aulajavaweb.model.AnimalVermifugo;

public class AnimalVermifugoDao extends DaoImpl<AnimalVermifugo> {

	public AnimalVermifugoDao() {
		super(AnimalVermifugo.class);
	}
	
}
