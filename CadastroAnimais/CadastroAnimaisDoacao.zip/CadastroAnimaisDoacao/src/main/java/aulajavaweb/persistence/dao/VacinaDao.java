package aulajavaweb.persistence.dao;

import aulajavaweb.model.Vacina;

public class VacinaDao extends DaoImpl<Vacina> {

	public VacinaDao() {
		super(Vacina.class);
	}
	
}
