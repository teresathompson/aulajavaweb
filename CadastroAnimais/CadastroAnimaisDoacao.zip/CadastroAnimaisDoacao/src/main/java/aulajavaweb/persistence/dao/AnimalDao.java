package aulajavaweb.persistence.dao;

import aulajavaweb.model.Animal;

public class AnimalDao extends DaoImpl<Animal> {

	public AnimalDao() {
		super(Animal.class);
	}
	
}
