package aulajavaweb.persistence.dao;

import aulajavaweb.model.HistoricoMedico;

public class HistoricoMedicoDao extends DaoImpl<HistoricoMedico> {

	public HistoricoMedicoDao() {
		super(HistoricoMedico.class);
	}
	
}
