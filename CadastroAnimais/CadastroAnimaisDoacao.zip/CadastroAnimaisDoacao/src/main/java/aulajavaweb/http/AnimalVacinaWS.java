package aulajavaweb.http;

public class AnimalVacinaWS {

}
