package aulajavaweb.http;

import javax.ws.rs.Path;

@Path("model")
public class ModelWS {
	
}
