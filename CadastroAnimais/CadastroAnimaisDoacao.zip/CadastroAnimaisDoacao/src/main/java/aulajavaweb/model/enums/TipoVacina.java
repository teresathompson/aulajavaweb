package aulajavaweb.model.enums;

public enum TipoVacina {
 RAIVA, V8, V11, V10,V12, V14, TRIPLICE_FELINA, LEPTOSPIROSE, CINOMOSE,TOSSE_DOS_CANIS, GIARDIA
}
