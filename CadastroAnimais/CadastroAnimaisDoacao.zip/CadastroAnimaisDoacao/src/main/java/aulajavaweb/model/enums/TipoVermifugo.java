package aulajavaweb.model.enums;

public enum TipoVermifugo {
	
	AMPLO_ESPECTRO, SIMPLES

}
