package aulajavaweb.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public interface Model {

	Integer getId();
	
}
