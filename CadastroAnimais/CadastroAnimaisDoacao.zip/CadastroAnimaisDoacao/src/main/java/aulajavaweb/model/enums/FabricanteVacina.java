package aulajavaweb.model.enums;

public enum FabricanteVacina {
 Merial, Hertape, BioVet, Virbac,Vencofarma,Novartis
}
